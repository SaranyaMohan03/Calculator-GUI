
package calc;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.System.err;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Stack;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author HP
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Button add;
    @FXML
    private Button nine;
    private Button sub;
    @FXML
    private Button six;
    @FXML
    private Button one;
    @FXML
    private Button clear;
    @FXML
    private Button seven;
    @FXML
    private Label label;
    @FXML
    private Button two;
    @FXML
    private Button three;
    @FXML
    private Button percent;
    @FXML
    private Button point;
    @FXML
    private Button eight;
    @FXML
    private Button zero;
    @FXML
    private Button equal;
    @FXML
    private Button four;
    @FXML
    private Button divide;
    @FXML
    private Button multiply;
    @FXML
    private Button five;
    @FXML
    public TextField input;
    float data;
    int operation;
    float display;    
    float number1;
    @FXML
    private Button minus;
    @FXML
    private Button plusorminus;
    @FXML
    public void handleButtonAction(ActionEvent event) throws IOException
    {
        if(event.getSource()==one)
        {
          input.setText(input.getText()+"1");
          number1=1;
        }
      else if(event.getSource()==two)
        {
          input.setText(input.getText()+"2");
          number1=2;
        }
      else if(event.getSource()==three)
        {
          input.setText(input.getText()+"3");
          number1=3;
        }
     else if(event.getSource()==four)
        {
          input.setText(input.getText()+"4");
          number1=4;
        }
     else if(event.getSource()==five)
        {
          input.setText(input.getText()+"5");
          number1=5;
        }
     else if(event.getSource()==six)
        {
          input.setText(input.getText()+"6");
          number1=6;
        }
     else if(event.getSource()== seven)
        {
          input.setText(input.getText()+"7");
          number1=7;
        }
     else if(event.getSource()== eight)
        {
          input.setText(input.getText()+"8");
          number1=8;
        }
     else if(event.getSource()== nine)
        {
          input.setText(input.getText()+"9");
          number1=9;
        }
     else if(event.getSource()== zero)
        {
          input.setText(input.getText()+"0");
          number1=0;
        }
      else if(event.getSource()== clear)
        { 
            input.clear();
            number1=0;
            data=0;        
         }
      else if(event.getSource()== add)
        {
          input.setText(input.getText()+ "+");
          operation=1;
        }
      else if(event.getSource()== minus)
        {
          input.setText(input.getText()+ "-");
          operation=2;
        }
      else if(event.getSource()== multiply)
        {
          input.setText(input.getText()+ "*");
          operation=3;
        }
     else if(event.getSource()== divide)
        {
           data=data + number1;         
          input.setText(input.getText()+ "/");
          operation=4;
        }
      else if(event.getSource()== percent)
        {
          input.setText("%");
          display = number1 / 100;
          input.setText(String.valueOf(display));
        }
      else if(event.getSource()== plusorminus)
      {
          display = number1 * (-1);
          input.setText(String.valueOf(display));
      }
      else if(event.getSource()== equal)
       {
               
           try{
           System.out.println("input: "+input.getText());
               String input1 = " "+input.getText()+" ";
               //String input1 = " "+"6-2+2*100/50-25/5+1*6"+" ";
               //System.out.println(subtraction(addition(multiply(division(input1)))));
               //input.setText(subtraction(addition(multiply(division(input1)))));
               
               String strr1=division(input1);
               System.out.println("strr1 is: "+strr1);
               strr1=" "+strr1+" ";
               String strr2=multiply(strr1);
               System.out.println("strr2 is: " +strr2);
               strr2=" "+strr2+" ";
               String strr3=addition(strr2);
               
               strr3=" "+strr3+" ";
               System.out.println("strr3 is: " + strr3);
               String strr4=subtraction(strr3);
               System.out.println("final ans is: "+strr4);
               
               input.setText(strr4.trim());

               String result = input1+"="+strr4;
               System.out.println("result"+result);
               writeUsingFile(result);
           }catch(Exception err){
               System.out.println("You have entered incorrect input!");
               input.setText("You have entered incorrect input!");
           }
        }
        else if(event.getSource()== point)
        {
          input.setText(input.getText()+ ".");
          
        }
    }

    
    public static String division(String input){
                    //for division
                String str1 = ""; 
                String str2 = "";
                String str3 = "";
                double a=0;
                double b=0;
                double result;
                int i=0,j=0,k=0,count=0;
                System.out.println("HIiiiiii");
                System.out.println("Input is:"+input);
                for(i=0; i<input.length(); i++){
                    System.out.println("Lenth is:"+input.length());
                    char c = input.charAt(i);
                    System.out.println("i is: "+i);
                    if(c == '/'){
                        count++;
                        for(j=i-1; (input.charAt(j) == '1' || input.charAt(j) == '2' || input.charAt(j) == '3' || input.charAt(j) == '4' || input.charAt(j) == '5' || input.charAt(j) == '6' || input.charAt(j) == '7' || input.charAt(j) == '8' || input.charAt(j) == '9' || input.charAt(j) == '0' || input.charAt(j) == '.') && j>=0 ; j--){         //|| j!= '*' || j!= '-'
                            System.out.println("j is:"+j);    
                            str1 = str1 + input.substring(j,j+1);
                            System.out.println("STR1 is:"+str1);
                        }

                        for(k=i+1;  input.charAt(k) == '1' || input.charAt(k) == '2' || input.charAt(k) == '3' || input.charAt(k) == '4' || input.charAt(k) == '5' || input.charAt(k) == '6' || input.charAt(k) == '7' || input.charAt(k) == '8' || input.charAt(k) == '9' || input.charAt(k) == '0' || input.charAt(k) == '.' ; k++){         
                            System.out.println("We are inside K"+str2);
                            str2 = str2 + input.substring(k,k+1);

                        }
                            StringBuilder sb1 = new StringBuilder(str1);
                            str1 = sb1.reverse().toString();
                            a = Double.parseDouble(str1);
                            System.out.println("A is :"+a);
                            
                            b = Double.parseDouble(str2);
                            System.out.println("B is :"+b);
                            result=a/b;
                            System.out.println("Result is: "+result);
                            str3=input.substring(0,j+1)+Double.toString(result)+input.substring((k),input.length());
                            System.out.println("Final string is:"+str3);
                            if(str3.contains("/")){
                               str3=division(str3); 
                            }
                            return str3;
                    }
                }
                if(count>0){
                    return str3;
                }else{
                return input;
                }
           }
          
           
           public static String multiply(String input){
                    //for division
                String str1 = ""; 
                String str2 = "";
                String str3 = "";
                double a=0;
                double b=0;
                double result;
                int i=0,j=0,k=0,count=0;
                for(i=0; i<input.length(); i++){
                    char c = input.charAt(i);
                    if(c == '*'){
                        count++;
                        for(j=i-1; input.charAt(j) == '1' || input.charAt(j) == '2' || input.charAt(j) == '3' || input.charAt(j) == '4' || input.charAt(j) == '5' || input.charAt(j) == '6' || input.charAt(j) == '7' || input.charAt(j) == '8' || input.charAt(j) == '9' || input.charAt(j) == '0' || input.charAt(j) == '.' ; j--){         //|| j!= '*' || j!= '-'
                            str1 = str1 + input.substring(j,j+1);

                        }

                        for(k=i+1;  input.charAt(k) == '1' || input.charAt(k) == '2' || input.charAt(k) == '3' || input.charAt(k) == '4' || input.charAt(k) == '5' || input.charAt(k) == '6' || input.charAt(k) == '7' || input.charAt(k) == '8' || input.charAt(k) == '9' || input.charAt(k) == '0' || input.charAt(k) == '.' ; k++){         
                            str2 = str2 + input.substring(k,k+1);

                        }
                            
                            StringBuilder sb1 = new StringBuilder(str1);
                            str1 = sb1.reverse().toString();
                            a = Double.parseDouble(str1);
                            System.out.println("a is: "+ a);
                            b = Double.parseDouble(str2);
                            System.out.println("b is: "+ b);
                            result=a*b;
                            System.out.println("Result is: "+result);
                            str3=input.substring(0,j+1)+Double.toString(result)+input.substring((k),input.length());
                            System.out.println("Final string is:"+str3);
                            if(str3.contains("*")){
                               str3=multiply(str3); 
                            }
                            return str3;
                        
                    }
                }
                if(count>0){
                    return str3;
                }else{
                return input;
                }
           }
 
                      
           public static String addition(String input){
                    //for division
                String str1 = ""; 
                String str2 = "";
                String str3 = "";
                double a=0;
                double b=0;
                double result;
                int i=0,j=0,k=0,count=0,z=0;
                for(int x=0; x<input.length(); x++){
                    if(input.charAt(x) == '+' && input.charAt(x-1)==' '){
                        System.out.println("We are inside if +:");
                        z=x;
                        break;
                    }
                    else{
                        System.out.println("We are inside else:");
                        z=0;
                    }       
                }

                for(i=z+1; i<input.length(); i++){
                    char c = input.charAt(i);
                    if(c == '+'){
                        count++;
                        for(j=i-1; input.charAt(j) == '1' || input.charAt(j) == '2' || input.charAt(j) == '3' || input.charAt(j) == '4' || input.charAt(j) == '5' || input.charAt(j) == '6' || input.charAt(j) == '7' || input.charAt(j) == '8' || input.charAt(j) == '9' || input.charAt(j) == '0' || input.charAt(j) == '.' ; j--){         //|| j!= '*' || j!= '-'
                            if(input.charAt(j-1)=='+' || input.charAt(j-1)=='-'){
                                str1 = str1 + input.substring(j,j+1);
                                System.out.println("str1:::"+str1);
                                str1 = str1 + input.substring(j-1,j);
                                System.out.println("str1::::"+str1);
                            }
                            else{
                                System.out.println("str1: "+str1);
                                str1 = str1 + input.substring(j,j+1);
                                System.out.println("str1:: "+str1);
                            }     
                        }

                        for(k=i+1;  input.charAt(k) == '1' || input.charAt(k) == '2' || input.charAt(k) == '3' || input.charAt(k) == '4' || input.charAt(k) == '5' || input.charAt(k) == '6' || input.charAt(k) == '7' || input.charAt(k) == '8' || input.charAt(k) == '9' || input.charAt(k) == '0' || input.charAt(k) == '.' ; k++){         
                            str2 = str2 + input.substring(k,k+1);
                            //b = Double.parseDouble(str2);
                            //System.out.println("b is: "+ b);
                        }
                          
                        StringBuilder sb1 = new StringBuilder(str1);
                        System.out.println("str1 before reverse: "+str1);
                        str1 = sb1.reverse().toString();
                        a = Double.parseDouble(str1);
                        b = Double.parseDouble(str2);
                        
                          result=a+b;
                            System.out.println("Result is: "+result);
                            if(input.charAt(j)=='+' || input.charAt(j)=='-'){
                                if(result>0){
                                    str3=input.substring(0,j)+"+"+Double.toString(result)+input.substring((k),input.length());
                                }
                                else if(result==0){
                                    str3=input.substring(0,j)+input.substring((k),input.length());
                                }
                                else{
                                    str3=input.substring(0,j)+Double.toString(result)+input.substring((k),input.length());
                                }
                                
                            }
                            else{
                                str3=input.substring(0,j+1)+Double.toString(result)+input.substring((k),input.length());
                            }
                            System.out.println("Final string is:"+str3);
                            if(str3.contains("+")){
                                System.out.println("Length is :"+str3.length());
                               str3=addition(str3); 
                            }
                            return str3;
                            
                    }
                }
                if(count>0){
                    return str3;
                }else{
                return input;
                }
           }           
    
           
           public static String subtraction(String input){
                    //for division
                String str1 = ""; 
                String str2 = "";
                String str3 = "";
                double a=0;
                double b=0;
                double result;
                int i=0,j=0,k=0,count=0,z=0;
                for(int x=0; x<input.length(); x++){
                    if(input.charAt(x) == '-' && input.charAt(x-1)==' '){
                        System.out.println("We are inside if +:");
                        z=x;
                        break;
                    }
                    else{
                        System.out.println("We are inside else:");
                        z=0;
                    }       
                }
                for(i=z+1; i<input.length(); i++){
                    char c = input.charAt(i);
                    if(c == '-'){
                        count++;
                        for(j=i-1; input.charAt(j) == '1' || input.charAt(j) == '2' || input.charAt(j) == '3' || input.charAt(j) == '4' || input.charAt(j) == '5' || input.charAt(j) == '6' || input.charAt(j) == '7' || input.charAt(j) == '8' || input.charAt(j) == '9' || input.charAt(j) == '0' || input.charAt(j) == '.' ; j--){         //|| j!= '*' || j!= '-'
                            if(input.charAt(j-1)=='+' || input.charAt(j-1)=='-'){
                                str1 = str1 + input.substring(j,j+1);
                                System.out.println("str1:::"+str1);
                                str1 = str1 + input.substring(j-1,j);
                            }
                            else{
                                System.out.println("str1: "+str1);
                                str1 = str1 + input.substring(j,j+1);
                                System.out.println("str1:: "+str1);

                            } 
                        }

                        for(k=i+1;  input.charAt(k) == '1' || input.charAt(k) == '2' || input.charAt(k) == '3' || input.charAt(k) == '4' || input.charAt(k) == '5' || input.charAt(k) == '6' || input.charAt(k) == '7' || input.charAt(k) == '8' || input.charAt(k) == '9' || input.charAt(k) == '0' || input.charAt(k) == '.' ; k++){         
                            str2 = str2 + input.substring(k,k+1);
                            //b = Double.parseDouble(str2);
                            //System.out.println("b is: "+ b);
                        }
                        StringBuilder sb1 = new StringBuilder(str1);
                        System.out.println("str1 before reverse: "+str1);
                        str1 = sb1.reverse().toString();
                        a = Double.parseDouble(str1);
                        b = Double.parseDouble(str2);
                        result=a-b;
                        System.out.println("Result is: "+result);
                        
                        if(input.charAt(j)=='+' || input.charAt(j)=='-'){
                            if(result>0){
                                str3=input.substring(0,j)+"+"+Double.toString(result)+input.substring((k),input.length());
                            }
                            else if(result==0){
                                str3=input.substring(0,j)+input.substring((k),input.length());
                            }
                            else{
                                str3=input.substring(0,j)+Double.toString(result)+input.substring((k),input.length());
                            }

                        }
                        else{
                            str3=input.substring(0,j+1)+Double.toString(result)+input.substring((k),input.length());
                        }
                        
                        System.out.println("Final string is:"+str3);
                            if(str3.contains("-")){
                               str3=subtraction(str3); 
                            }
                            return str3;
                    }
                }
                if(count>0){
                    return str3;
                }else{
                    System.out.println("We are here: ");
                    return input;
                }
           } 
    
    
    
    public static void writeUsingFile(String s) throws IOException
    {
        BufferedWriter outs = new BufferedWriter(new FileWriter("test.txt",true));
        outs.write(s);
        outs.newLine();
        outs.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
